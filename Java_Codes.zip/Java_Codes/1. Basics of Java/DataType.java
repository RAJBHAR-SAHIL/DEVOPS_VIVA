public class DataType {
    public static void main(String[] args) {
        byte a = 127;
        short b = 32000;
        int c = 100000;
        long d = 123456789L;
        float e = 3.14f;
        double f = 3.14159;
        char g = 'A';
        boolean h = true;

        System.out.println("Byte Value: " + a);
        System.out.println("Short Value: " + b);
        System.out.println("Int Value: " + c);
        System.out.println("Long Value: " + d);
        System.out.println("Float Value: " + e);
        System.out.println("Double Value: " + f);
        System.out.println("Char Value: " + g);
        System.out.println("Boolean Value: " + h);
    }
}