package com.sow.controller;

import com.sow.Controller.SOWController;
import com.sow.Entity.SOW;
import com.sow.Service.SOWService;

// import org.hibernate.sql.Delete;
// import org.hibernate.sql.Update;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.io.IOException;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class SOWControllerTest {

    private MockMvc mockMvc;

    @Mock
    private SOWService sowService;

    @InjectMocks
    private SOWController sowController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(sowController).build();
    }

    @Test
    public void testGetAllSOWs() throws Exception {
        when(sowService.getAllSOWs()).thenReturn(List.of(new SOW(), new SOW()));
        mockMvc.perform(get("/sow"))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetSOWById() throws Exception {
        SOW sow = new SOW();
        sow.setId(1L);
        when(sowService.getSOWById(1L)).thenReturn(sow);
        mockMvc.perform(get("/sow/1"))
                .andExpect(status().isOk());
    }

    // Get SOW by ID – Not Found
    @Test
    public void testGetSOWByIdNotFound() throws Exception {
        when(sowService.getSOWById(999L)).thenThrow(new NoSuchElementException("SOW not found with id: 999"));

        mockMvc.perform(get("/sow/999"))
                .andExpect(status().isNotFound())
                .andExpect(content().string("SOW not found with id: 999"));
    }

    @Test
    public void testCreateSOW() throws Exception {
        SOW sow = new SOW();
        sow.setId(1L);
        when(sowService.createSOW(any())).thenReturn(sow);
        mockMvc.perform(post("/sow")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"nemsid\":\"NEMS123\",\"projectName\":\"Project\",\"woName\":\"WO1\"}"))
                .andExpect(status().isOk());
    }

    // Create SOW – Duplicate Entry
    @Test
    public void testCreateSOWDuplicate() throws Exception {
        when(sowService.createSOW(any()))
                .thenThrow(new IllegalArgumentException("SOW with identical data already exists."));

        mockMvc.perform(post("/sow")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"nemsid\":\"NEMS123\",\"projectName\":\"Project\",\"woName\":\"WO1\"}"))
                .andExpect(status().isConflict())
                .andExpect(content().string("SOW with identical data already exists."));
    }

    @Test
    public void testUpdateSOW() throws Exception {
        SOW sow = new SOW();
        sow.setId(1L);
        when(sowService.updateSOW(eq(1L), any())).thenReturn(sow);
        mockMvc.perform(put("/sow/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"nemsid\":\"NEMS123\",\"projectName\":\"Project\",\"woName\":\"WO1\"}"))
                .andExpect(status().isOk());
    }

    // Update SOW – Not Found
    @Test
    public void testUpdateSOWNotFound() throws Exception {
        when(sowService.updateSOW(eq(1L), any())).thenThrow(new NoSuchElementException("SOW not found with id: 1"));

        mockMvc.perform(put("/sow/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"nemsid\":\"NEMS123\",\"projectName\":\"Project\",\"woName\":\"WO1\"}"))
                .andExpect(status().isNotFound())
                .andExpect(content().string("SOW not found with id: 1"));
    }

    // Update SOW – Duplicate Entry
    @Test
    public void testUpdateSOWDuplicate() throws Exception {
        when(sowService.updateSOW(eq(1L), any()))
                .thenThrow(new IllegalArgumentException("Updated SOW already exists with identical data."));

        mockMvc.perform(put("/sow/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"nemsid\":\"NEMS123\",\"projectName\":\"Project\",\"woName\":\"WO1\"}"))
                .andExpect(status().isConflict())
                .andExpect(content().string("Updated SOW already exists with identical data."));
    }

    @Test
    public void testDeleteSOW() throws Exception {
        doNothing().when(sowService).deleteSOW(1L);
        mockMvc.perform(delete("/sow/1"))
                .andExpect(status().isNoContent());
    }

    // Delete SOW – Not Found
    @Test
    public void testDeleteSOWNotFound() throws Exception {
        doThrow(new NoSuchElementException("SOW not found with id: 1")).when(sowService).deleteSOW(1L);

        mockMvc.perform(delete("/sow/1"))
                .andExpect(status().isNotFound())
                .andExpect(content().string("SOW not found with id: 1"));
    }

    @Test
    public void testUploadCsvSuccess() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test.csv", "text/csv",
                "CITI Sector [L5],CITI LOB [L6],Project Name,NEMSID,Start Date,End Date,Role,Tech Category,Level,Country,Number of roles,Skill,WO Name\nICG,TTS,Project,NEMS123,01-01-2024,31-12-2024,Dev,Tech,Level,US,5,Java,WO1"
                        .getBytes());

        when(sowService.uploadCsv(any())).thenReturn(List.of("Row 2: Successfully added."));
        mockMvc.perform(multipart("/sow/upload").file(file))
                .andExpect(status().isOk());
    }

    @Test
    public void testUploadCsvWithErrors() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test.csv", "text/csv",
                "CITI Sector [L5],CITI LOB [L6],Project Name,NEMSID,Start Date,End Date,Role,Tech Category,Level,Country,Number of roles,Skill,WO Name\nICG,TTS,Project,NEMS123,invalid,31-12-2024,Dev,Tech,Level,US,5,Java,WO1"
                        .getBytes());

        when(sowService.uploadCsv(any())).thenReturn(List.of("Row 2: Error - Invalid date format."));
        mockMvc.perform(multipart("/sow/upload").file(file))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void testUploadCsvIOException() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test.csv", "text/csv", "data".getBytes());
        when(sowService.uploadCsv(any())).thenThrow(new IOException("Error reading CSV file"));
        mockMvc.perform(multipart("/sow/upload").file(file))
                .andExpect(status().isInternalServerError());
    }
}
