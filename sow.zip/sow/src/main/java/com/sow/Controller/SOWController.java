package com.sow.Controller;

import com.sow.Entity.SOW;
import com.sow.Service.SOWService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/sow")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SOWController {

    @Autowired
    private SOWService sowService;

    // GET all SOW records
    @GetMapping
    public ResponseEntity<List<SOW>> getAllSOWs() {
        return ResponseEntity.ok(sowService.getAllSOWs());
    }

    // GET SOW by ID
    @GetMapping("/{id}")
    public ResponseEntity<SOW> getSOWById(@PathVariable Long id) {
        return ResponseEntity.ok(sowService.getSOWById(id));
    }

    // POST create new SOW
    @PostMapping
    public ResponseEntity<SOW> createSOW(@RequestBody SOW sow) {
        return ResponseEntity.ok(sowService.createSOW(sow));
    }

    // PUT update SOW
    @PutMapping("/{id}")
    public ResponseEntity<SOW> updateSOW(@PathVariable Long id, @RequestBody SOW sow) {
        return ResponseEntity.ok(sowService.updateSOW(id, sow));
    }

    // DELETE SOW by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSOW(@PathVariable Long id) {
        sowService.deleteSOW(id);
        return ResponseEntity.noContent().build();
    }

    // POST upload CSV
    @PostMapping("/upload")
    public ResponseEntity<?> uploadCsv(@RequestParam("file") MultipartFile file) {
        try {
            List<String> messages = sowService.uploadCsv(file);

            boolean hasErrors = messages.stream()
                    .anyMatch(msg -> msg.contains("Error") || msg.contains("Invalid") || msg.contains("Duplicate"));

            if (hasErrors) {
                return ResponseEntity.badRequest().body(messages);
            } else {
                return ResponseEntity.ok(messages);
            }

        } catch (IOException e) {
            return ResponseEntity.internalServerError()
                    .body("Error reading CSV file: " + e.getMessage());
        }
    }

    // ✅ Exception Handlers

    @ExceptionHandler(NoSuchElementException.class)
    public ResponseEntity<String> handleNotFound(NoSuchElementException ex) {
        return ResponseEntity.status(404).body(ex.getMessage());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handleConflict(IllegalArgumentException ex) {return ResponseEntity.status(409).body(ex.getMessage());
    }

}
