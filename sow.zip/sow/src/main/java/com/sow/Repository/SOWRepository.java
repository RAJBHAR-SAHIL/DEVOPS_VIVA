package com.sow.Repository;

import java.sql.Date;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sow.Entity.SOW;

@Repository
public interface SOWRepository extends JpaRepository<SOW, Long> {
    // boolean existsByNemsidAndProjectNameAndWoName(String nemsid, String
    // projectName, String woName);
    // Optional<SOW> findByNemsidAndProjectNameAndWoName(String nemsid, String
    // projectName, String woName);

    @Query("SELECT s FROM SOW s WHERE " +
            "s.citiSectorL5 = :citiSectorL5 AND " +
            "s.citiLobL6 = :citiLobL6 AND " +
            "s.projectName = :projectName AND " +
            "s.nemsid = :nemsid AND " +
            "s.startDate = :startDate AND " +
            "s.endDate = :endDate AND " +
            "s.citiRole = :citiRole AND " +
            "s.techCategory = :techCategory AND " +
            "s.citiLevel = :citiLevel AND " +
            "s.country = :country AND " +
            "s.numberOfRoles = :numberOfRoles AND " +
            "s.skill = :skill AND " +
            "s.woName = :woName")
    Optional<SOW> findFullMatch(
            @Param("citiSectorL5") String citiSectorL5,
            @Param("citiLobL6") String citiLobL6,
            @Param("projectName") String projectName,
            @Param("nemsid") String nemsid,
            @Param("startDate") Date startDate,
            @Param("endDate") Date endDate,
            @Param("citiRole") String citiRole,
            @Param("techCategory") String techCategory,
            @Param("citiLevel") String citiLevel,
            @Param("country") String country,
            @Param("numberOfRoles") Integer numberOfRoles,
            @Param("skill") String skill,
            @Param("woName") String woName);

}
