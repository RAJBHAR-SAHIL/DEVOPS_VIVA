package com.sow.Service;

import com.sow.Entity.SOW;
import com.sow.Repository.SOWRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class SOWService {

    @Autowired
    private SOWRepository sowRepository;

    public List<SOW> getAllSOWs() {
        return sowRepository.findAll();
    }

    public SOW getSOWById(Long id) {
        return sowRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("SOW not found with id: " + id));
    }

    public SOW createSOW(SOW sow) {
        Optional<SOW> existing = sowRepository.findFullMatch(
                sow.getCitiSectorL5(), sow.getCitiLobL6(), sow.getProjectName(), sow.getNemsid(),
                sow.getStartDate(), sow.getEndDate(), sow.getCitiRole(), sow.getTechCategory(),
                sow.getCitiLevel(), sow.getCountry(), sow.getNumberOfRoles(), sow.getSkill(), sow.getWoName());

        if (existing.isPresent()) {
            throw new IllegalArgumentException("SOW with identical data already exists.");
        }

        return sowRepository.save(sow);
    }

    public SOW updateSOW(Long id, SOW updatedSOW) {
        sowRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("SOW not found with id: " + id));

        Optional<SOW> existing = sowRepository.findFullMatch(
                updatedSOW.getCitiSectorL5(), updatedSOW.getCitiLobL6(), updatedSOW.getProjectName(),
                updatedSOW.getNemsid(),
                updatedSOW.getStartDate(), updatedSOW.getEndDate(), updatedSOW.getCitiRole(),
                updatedSOW.getTechCategory(),
                updatedSOW.getCitiLevel(), updatedSOW.getCountry(), updatedSOW.getNumberOfRoles(),
                updatedSOW.getSkill(), updatedSOW.getWoName());

        if (existing.isPresent()) {
            throw new IllegalArgumentException("Updated SOW already exists with identical data.");
        }

        return sowRepository.save(updatedSOW);
    }

    public void deleteSOW(Long id) {
        SOW sow = sowRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("SOW not found with id: " + id));
        sowRepository.delete(sow);
    }

    public List<String> uploadCsv(MultipartFile file) throws IOException {
        List<String> messages = new ArrayList<>();
        Set<String> seenEntries = new HashSet<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            int rowNum = 0;

            while ((line = reader.readLine()) != null) {
                rowNum++;
                if (rowNum == 1)
                    continue; // Skip header

                String[] fields = line.split(",");

                if (fields.length != 13) {
                    messages.add("Row " + rowNum + ": Invalid number of columns.");
                    continue;
                }

                for (int i = 0; i < fields.length; i++) {
                    fields[i] = fields[i].trim();
                }

                String key = String.join("|", fields);
                if (!seenEntries.add(key)) {
                    messages.add("Row " + rowNum + ": Duplicate entry in file. Skipped.");
                    continue;
                }

                java.util.Date parsedStartDate;
                java.util.Date parsedEndDate;
                try {
                    parsedStartDate = sdf.parse(fields[4]);
                    parsedEndDate = sdf.parse(fields[5]);
                } catch (Exception e) {
                    messages.add("Row " + rowNum + ": Invalid date format. Expected dd-MM-yyyy.");
                    continue;
                }

                Integer numberOfRoles;
                try {
                    numberOfRoles = Integer.parseInt(fields[10]);
                } catch (NumberFormatException e) {
                    messages.add("Row " + rowNum + ": Invalid number format for 'Number of roles'.");
                    continue;
                }

                Optional<SOW> fullMatch = sowRepository.findFullMatch(
                        fields[0], fields[1], fields[2], fields[3],
                        new Date(parsedStartDate.getTime()),
                        new Date(parsedEndDate.getTime()),
                        fields[6], fields[7], fields[8],
                        fields[9], numberOfRoles, fields[11], fields[12]);

                if (fullMatch.isPresent()) {
                    messages.add("Row " + rowNum + ": Identical entry already exists. Skipped.");
                    continue;
                }

                try {
                    SOW sow = new SOW();
                    sow.setCitiSectorL5(fields[0]);
                    sow.setCitiLobL6(fields[1]);
                    sow.setProjectName(fields[2]);
                    sow.setNemsid(fields[3]);
                    sow.setStartDate(new Date(parsedStartDate.getTime()));
                    sow.setEndDate(new Date(parsedEndDate.getTime()));
                    sow.setCitiRole(fields[6]);
                    sow.setTechCategory(fields[7]);
                    sow.setCitiLevel(fields[8]);
                    sow.setCountry(fields[9]);
                    sow.setNumberOfRoles(numberOfRoles);
                    sow.setSkill(fields[11]);
                    sow.setWoName(fields[12]);

                    sowRepository.save(sow);
                    messages.add("Row " + rowNum + ": Successfully added.");
                } catch (Exception e) {
                    messages.add("Row " + rowNum + ": Error - " + e.getMessage());
                }
            }
        }

        return messages;
    }
}
