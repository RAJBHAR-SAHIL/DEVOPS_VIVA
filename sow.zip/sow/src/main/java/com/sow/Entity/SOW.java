package com.sow.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "sow")
public class SOW {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "CITI_Sector_L5")
    private String citiSectorL5;

    @Column(name = "CITI_LOB_L6")
    private String citiLobL6;

    @Column(name = "Project_Name", columnDefinition = "TEXT")
    private String projectName;

    @Column(name = "NEMSID")
    private String nemsid;

    @Column(name = "Start_Date")
    private java.sql.Date startDate;

    @Column(name = "End_Date")
    private java.sql.Date endDate;

    @Column(name = "Citi_role")
    private String citiRole;

    @Column(name = "Tech_Category")
    private String techCategory;

    @Column(name = "Citi_level")
    private String citiLevel;

    @Column(name = "Country")
    private String country;

    @Column(name = "Number_of_roles")
    private Integer numberOfRoles;

    @Column(name = "Skill", columnDefinition = "TEXT")
    private String skill;

    @Column(name = "WO_Name", length = 30)
    private String woName;
}
