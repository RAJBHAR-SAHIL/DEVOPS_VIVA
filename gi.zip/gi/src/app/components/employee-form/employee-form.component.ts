import { Component } from '@angular/core';
import { Employee } from '../../model/employee.model';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from '../../services/employee.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-employee-form',
  imports: [FormsModule],
  templateUrl: './employee-form.component.html',
  styleUrl: './employee-form.component.css'
})
export class EmployeeFormComponent {
form: Employee = { email: '', name: '', department: '' };
  selectedFile: File | null = null;
  isEdit = false;
  id: number | null = null;

  constructor(private route: ActivatedRoute, private service: EmployeeService, private router: Router) {}

  ngOnInit() {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.isEdit = true;
      this.id = +idParam;
      this.service.get(this.id).subscribe(data => this.form = data);
    }
  }

  onFileChange(e: any) { this.selectedFile = e.target.files[0]; }

  submit() {
    this.form.file = this.selectedFile!;
    if (this.isEdit && this.id) {
      this.service.update(this.id, this.form).subscribe(() => this.router.navigate(['/']));
    } else {
      this.service.create(this.form).subscribe(() => this.router.navigate(['/']));
    }
  }
}
