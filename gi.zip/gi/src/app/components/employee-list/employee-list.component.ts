import { Component } from '@angular/core';
import { Employee } from '../../model/employee.model';
import { EmployeeService } from '../../services/employee.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-employee-list',
  imports: [CommonModule],
  templateUrl: './employee-list.component.html',
  styleUrl: './employee-list.component.css'
})
export class EmployeeListComponent {
employees: Employee[] = [];

  constructor(private service: EmployeeService, private router: Router) {}

  ngOnInit() { this.load(); }
  load() { this.service.getAll().subscribe(data => this.employees = data); }


  edit(id: number) { this.router.navigate(['/emp-form', id]); }
  delete(id: number) { this.service.delete(id).subscribe(() => this.load()); }
  download(id: number) { window.open(this.service.getDownloadUrl(id), '_blank'); }
}
