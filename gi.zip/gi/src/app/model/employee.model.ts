export interface Employee {
  id?: number;
  email: string;
  name: string;
  department: string;
  file?: File;
}