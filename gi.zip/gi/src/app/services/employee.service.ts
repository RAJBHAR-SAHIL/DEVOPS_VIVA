import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from '../model/employee.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
private api = 'http://localhost:8081/employees';
  constructor(private http: HttpClient) {}

  getAll() { return this.http.get<Employee[]>(`${this.api}/all`); }

  get(id: number) { return this.http.get<Employee>(`${this.api}/${id}`); }
  
  create(emp: Employee) {
    const form = new FormData();
    form.append('email', emp.email);
    form.append('name', emp.name);
    form.append('department', emp.department);
    if (emp.file) form.append('file', emp.file);
    return this.http.post<Employee>(`${this.api}/create`, form);
  }
  update(id: number, emp: Employee) {
    const form = new FormData();
    form.append('email', emp.email);
    form.append('name', emp.name);
    form.append('department', emp.department);
    if (emp.file) form.append('file', emp.file);
    return this.http.put<Employee>(`${this.api}/update/${id}`, form);
  }
  delete(id: number) { return this.http.delete(`${this.api}/delete/${id}`); }
  getDownloadUrl(id: number) { return `${this.api}/download/${id}`; }
}
