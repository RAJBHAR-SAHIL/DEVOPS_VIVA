import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';
import { EmployeeFormComponent } from './components/employee-form/employee-form.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { AuthGuard } from './auth/auth.guard';

const routes: Routes = [
  { path: "", component: EmployeeListComponent, canActivate: [AuthGuard] },
  { path: "emp-list", component: EmployeeListComponent, canActivate: [AuthGuard] },
  { path: "emp-form", component: EmployeeFormComponent, canActivate: [AuthGuard] },
  { path: "emp-form/:id", component: EmployeeFormComponent, canActivate: [AuthGuard] },
  { path: "login", component: LoginComponent },
  { path: "register", component: RegisterComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
