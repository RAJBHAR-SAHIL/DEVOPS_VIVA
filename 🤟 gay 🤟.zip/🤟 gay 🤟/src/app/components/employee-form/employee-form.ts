import { Component } from '@angular/core';
import { Employee } from '../../model/employee.model';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from '../../services/employee.service';

@Component({
  selector: 'app-employee-form',
  standalone: false,
  templateUrl: './employee-form.html',
  styleUrl: './employee-form.css',
})
export class EmployeeForm {
  form: Employee = { email: '', name: '', department: '' };
  selectedFile: File | null = null;
  isEdit = false;
  id: number | null = null;

  constructor(
    private route: ActivatedRoute,
    private service: EmployeeService,
    private router: Router
  ) {}

  ngOnInit() {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.isEdit = true;
      this.id = +idParam;
      this.service.get(this.id).subscribe((data) => (this.form = data));
    }
  }

  onFileChange(e: any) {
    this.selectedFile = e.target.files[0];
  }

  submit() {
    this.form.file = this.selectedFile!;
    if (this.isEdit && this.id) {
      this.service
        .update(this.id, this.form)
        .subscribe(() => this.router.navigate(['/emp-form']));
    } else {
      this.service
        .create(this.form)
        .subscribe(() => this.router.navigate(['/emp-form']));
    }
  }
}
