import { Component } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';
import { Router } from '@angular/router';
import { Employee } from '../../model/employee.model';

@Component({
  selector: 'app-employee-list',
  standalone: false,
  templateUrl: './employee-list.html',
  styleUrl: './employee-list.css',
})
export class EmployeeList {
  employees: Employee[] = [];
  constructor(private service: EmployeeService, private router: Router) {}

  ngOnInit() {
    this.load();
  }
  load() {
    this.service.getAll().subscribe((data) => (this.employees = data));
  }

  edit(id: number) {
    this.router.navigate(['/emp-form', id]);
  }
  delete(id: number) {
    this.service.delete(id).subscribe(() => this.load());
  }
  download(id: number) {
    window.open(this.service.getDownloadUrl(id), '_blank');
  }
}
