import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
private api = 'http://localhost:8081/auth';
  constructor(private http: HttpClient) {}

  login(username: string, password: string) {
    return this.http.post(this.api + '/login', { username, password }, { responseType: 'text' });
  }

  register(username: string, password: string) {
    return this.http.post(this.api + '/register', { username, password }, { responseType: 'text' });
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }

  logout() {
    localStorage.removeItem('token');
  }
}
