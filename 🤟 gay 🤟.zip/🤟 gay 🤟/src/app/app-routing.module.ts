import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth/auth.guard';
import { Home } from './components/home/home';
import { Login } from './components/login/login';
import { Register } from './components/register/register';
import { EmployeeList } from './components/employee-list/employee-list';
import { EmployeeForm } from './components/employee-form/employee-form';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: Home,
    canActivate: [AuthGuard],
  },
  {
    path: 'home',
    component: Home,
    canActivate: [AuthGuard],
  },
  {
    path: 'emp-list',
    component: EmployeeList,
    canActivate: [AuthGuard],
  },
  {
    path: 'emp-form',
    component: EmployeeForm,
    canActivate: [AuthGuard],
  },
  {
    path: 'emp-form/:id',
    component: EmployeeForm,
    canActivate: [AuthGuard],
  },
  { path: 'login', component: Login },
  { path: 'register', component: Register },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
