package com.bankappservice.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.bankappservice.Entity.Employee;

import com.bankappservice.Repository.EmployeeRepository;

@Service
public class EmployeeService {

    private final String uploadDir = "uploaded_files/";

    private static final Logger logger = LogManager.getLogger(EmployeeService.class);

    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> getAllEmployees() {
        logger.info("Fetching all employees");
        return employeeRepository.findAll();
    }

    public Employee getEmployeeById(Long id) {
        logger.info("Fetching employee by ID: {}", id);
        return employeeRepository.findById(id).orElseThrow(() -> {
            logger.error("Employee not found with ID: {}", id);
            return new RuntimeException("Employee not found");
        });
    }

    public Employee updateEmployee(Long id, String email, String name, String dept, MultipartFile file)
            throws IOException {
        Employee e = getEmployeeById(id);
        if (e == null)
            return null;
        e.setEmail(email);
        e.setName(name);
        e.setDepartment(dept);
        if (!file.isEmpty()) {
            e.setFileName(file.getOriginalFilename());
            e.setFileType(file.getContentType());
            e.setFileData(file.getBytes());
        }
        return employeeRepository.save(e);
    }

    public void deleteEmployee(Long id) {
        logger.info("Deleting employee with ID: {}", id);
        try {
            employeeRepository.deleteById(id);
            logger.info("Deleted employee with ID: {}", id);
        } catch (Exception e) {
            logger.error("Error deleting employee with ID: {}", id, e);
            throw e;
        }
    }

    public Employee saveEmployee(String email, String name, String department, MultipartFile file) throws Exception {
        Employee emp = new Employee();
        emp.setEmail(email);
        emp.setName(name);
        emp.setDepartment(department);

        emp.setFileName(file.getOriginalFilename());
        emp.setFileType(file.getContentType());
        emp.setFileData(file.getBytes());

        // Save to local storage
        File localFile = new File(uploadDir + file.getOriginalFilename());
        localFile.getParentFile().mkdirs();
        try (FileOutputStream fos = new FileOutputStream(localFile)) {
            fos.write(file.getBytes());
        }

        return employeeRepository.save(emp);
    }

    public byte[] getFileDataById(Long id) throws Exception {
        Employee emp = employeeRepository.findById(id)
                .orElseThrow(() -> new Exception("Employee not found"));
        return emp.getFileData();
    }

    public String getFileNameById(Long id) throws Exception {
        Employee emp = employeeRepository.findById(id)
                .orElseThrow(() -> new Exception("Employee not found"));
        return emp.getFileName();
    }

    public String getFileTypeById(Long id) throws Exception {
        Employee emp = employeeRepository.findById(id)
                .orElseThrow(() -> new Exception("Employee not found"));
        return emp.getFileType();
    }

}
