package com.examly.springapp.exceptions;

public class UsernameAlreadyExistsException extends Exception{
    public UsernameAlreadyExistsException(String e){
        super(e);
    }
    
}
