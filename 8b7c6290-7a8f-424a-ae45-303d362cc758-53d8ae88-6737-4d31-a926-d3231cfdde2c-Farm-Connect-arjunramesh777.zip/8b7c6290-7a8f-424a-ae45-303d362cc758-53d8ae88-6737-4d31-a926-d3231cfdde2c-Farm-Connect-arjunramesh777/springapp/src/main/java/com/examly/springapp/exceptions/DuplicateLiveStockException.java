package com.examly.springapp.exceptions;

public class DuplicateLiveStockException extends Exception{
    public DuplicateLiveStockException(String e){
        super(e);
    }
}
