export interface Livestock {
    livestockId?: number;
    name: string;
    species: string;
    age: number;
    breed: string;
    healthCondition?: string;
    location: string;
    vaccinationStatus?: string;
    user?:{
        userId:number
    } 
}
