import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { LoginComponent } from './components/login/login.component';
import { CreatemedicineComponent } from './components/createmedicine/createmedicine.component';
import { ViewmedicineComponent } from './components/viewmedicine/viewmedicine.component';
import { CreatefeedComponent } from './components/createfeed/createfeed.component';
import { ViewfeedComponent } from './components/viewfeed/viewfeed.component';
import { SupplierrequestsComponent } from './components/supplierrequests/supplierrequests.component';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { CreatelivestockComponent } from './components/createlivestock/createlivestock.component';
import { ViewlivestockComponent } from './components/viewlivestock/viewlivestock.component';
import { OwnerviewmedicineComponent } from './components/ownerviewmedicine/ownerviewmedicine.component';
import { RequestformComponent } from './components/requestform/requestform.component';
import { OwnerviewfeedComponent } from './components/ownerviewfeed/ownerviewfeed.component';
import { OwnerviewrequestComponent } from './components/ownerviewrequest/ownerviewrequest.component';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { AuthguardComponent } from './components/authguard/authguard.component';
import { ErrorComponent } from './components/error/error.component';
import { OwnereditlivestockComponent } from './components/ownereditlivestock/ownereditlivestock.component';
import { SuppliereditfeedComponent } from './components/suppliereditfeed/suppliereditfeed.component';
import { SuppliereditmedicineComponent } from './components/suppliereditmedicine/suppliereditmedicine.component';
import { RoleGuard } from './services/role.guard';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';

const routes: Routes = [
  {path:"",redirectTo:'/home',pathMatch:'full'},
  {path:"home",component:HomeComponent},
  {path:"authguard",component:AuthguardComponent},
  {path:"error",component:ErrorComponent},
  {path:"registration",component:RegistrationComponent},
  {path:"login",component:LoginComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'contactus',component:ContactusComponent},
  

  {path:"addMedicine",component:CreatemedicineComponent,canActivate:[RoleGuard],data:{role:'SUPPLIER'}},
  {path:"viewMedicine",component:ViewmedicineComponent,canActivate:[RoleGuard],data:{role:'SUPPLIER'}},
  {path:"supplierEditMedicine/:medicineId",component:SuppliereditmedicineComponent,canActivate:[RoleGuard],data:{role:'SUPPLIER'}},
  {path:"addFeed",component:CreatefeedComponent,canActivate:[RoleGuard],data:{role:'SUPPLIER'}},
  {path:"viewFeed",component:ViewfeedComponent,canActivate:[RoleGuard],data:{role:'SUPPLIER'}},
  {path:"supplierEditFeed/:feedId",component:SuppliereditfeedComponent,canActivate:[RoleGuard],data:{role:'SUPPLIER'}},
  {path:"supplierRequest",component:SupplierrequestsComponent,canActivate:[RoleGuard],data:{role:'SUPPLIER'}},
  {path:"adminViewFeedBack",component:AdminviewfeedbackComponent,canActivate:[RoleGuard],data:{role:'SUPPLIER'}},
  
  
  {path:"addLivestock",component:CreatelivestockComponent,canActivate:[RoleGuard],data:{role:'OWNER'}},
  {path:"viewLivestock",component:ViewlivestockComponent,canActivate:[RoleGuard],data:{role:'OWNER'}},
  {path:"ownerEditLiveStock/:livestockId",component:OwnereditlivestockComponent,canActivate:[RoleGuard],data:{role:'OWNER'}},
  {path:"ownerViewMedicine",component:OwnerviewmedicineComponent,canActivate:[RoleGuard],data:{role:'OWNER'}},
  {path:"ownerViewFeed",component:OwnerviewfeedComponent,canActivate:[RoleGuard],data:{role:'OWNER'}},
  {path:"ownerRequest",component:OwnerviewrequestComponent,canActivate:[RoleGuard],data:{role:'OWNER'}},
  {path:"addFeedBack",component:UseraddfeedbackComponent,canActivate:[RoleGuard],data:{role:'OWNER'}},
  {path:"ViewFeedBack",component:UserviewfeedbackComponent,canActivate:[RoleGuard],data:{role:'OWNER'}},
  {path:"requestForm",component:RequestformComponent,canActivate:[RoleGuard],data:{role:'OWNER'}},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
