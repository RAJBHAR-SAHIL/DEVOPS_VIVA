import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { User } from 'src/app/models/user.model';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-adminviewfeedback',
  templateUrl: './adminviewfeedback.component.html',
  styleUrls: ['./adminviewfeedback.component.css']
})
export class AdminviewfeedbackComponent implements OnInit {
  feedback: Feedback[];
  selectedUser: any;
  isProfileModalOpen: boolean = false;
  users: User[] = [];

  constructor(private service: FeedbackService, private activateRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.getFeedbacks();
  }

  getFeedbacks() {
    this.service.getFeedbacks().subscribe(x => {
      this.feedback = x;
    });
  }

  showUserProfile(id: number): void {
    this.selectedUser = this.feedback.find(fd => fd.user.userId=== id);
    this.isProfileModalOpen = true;
  }

  closeProfileModal(): void {
    this.isProfileModalOpen = false;
    this.selectedUser = null;
  }
}



