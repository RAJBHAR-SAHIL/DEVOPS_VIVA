import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feed } from 'src/app/models/feed.model';
import { FeedService } from 'src/app/services/feed.service';

@Component({
  selector: 'app-ownerviewfeed',
  templateUrl: './ownerviewfeed.component.html',
  styleUrls: ['./ownerviewfeed.component.css']
})
export class OwnerviewfeedComponent implements OnInit {
  feeds: Feed[] = [];
  filteredFeeds: Feed[] = [];

  constructor(private router: Router, private service: FeedService) { }

  ngOnInit(): void {
    this.getAllFeed();
  }

  public getAllFeed(): void {
    this.service.getAllFeed().subscribe(feeds => {
      this.feeds = feeds.slice();
      this.filteredFeeds = feeds.slice();
    });
  }

  openRequestForm(feedId: number, feedName: string): void {
    this.router.navigate(['/requestForm'], { 
      queryParams: { 
        requestType: 'Feed', 
        sourceComponent: 'ownerviewfeed', 
        fId: feedId, 
        fName: feedName
      } 
    });
  }

  onSearch(event: any): void {
    const searchTerm = event.target.value.toLowerCase();
    this.filteredFeeds = this.feeds.filter(feed =>
      feed.feedName.toLowerCase().includes(searchTerm) ||
      feed.type.toLowerCase().includes(searchTerm) ||
      feed.description.toLowerCase().includes(searchTerm) ||
      feed.quantity.toString().toLowerCase().includes(searchTerm) ||
      feed.unit.toLowerCase().includes(searchTerm) ||
      feed.pricePerUnit.toString().toLowerCase().includes(searchTerm)
    );
  }

  onSortFieldChange(sortField: string): void {
    if (sortField) {
      this.filteredFeeds.sort((a, b) => {
        let valueA = a[sortField];
        let valueB = b[sortField];

        if (typeof valueA === 'string') {
          valueA = valueA.toLowerCase();
        }
        if (typeof valueB === 'string') {
          valueB = valueB.toLowerCase();
        }

        if (valueA < valueB) {
          return -1;
        } else if (valueA > valueB) {
          return 1;
        } else {
          return 0;
        }
      });
    }
  }
}
