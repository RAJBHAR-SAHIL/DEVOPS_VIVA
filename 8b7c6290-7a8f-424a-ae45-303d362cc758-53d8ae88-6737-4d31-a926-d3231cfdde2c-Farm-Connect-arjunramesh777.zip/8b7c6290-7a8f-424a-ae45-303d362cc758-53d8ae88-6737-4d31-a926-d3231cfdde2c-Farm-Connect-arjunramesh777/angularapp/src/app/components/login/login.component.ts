import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthUser } from 'src/app/models/AuthUser.model';
import { LoginUser } from 'src/app/models/login-user';
import { AuthService } from 'src/app/services/auth.service';
import { UserStoreService } from 'src/app/services/user-store.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username: string = '';
  password: string = '';
  authUser: AuthUser;
  passwordFieldType: string = 'password';

  constructor(
    private store: UserStoreService,
    private service: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {}

  public login(): void {
    let loginUser = new LoginUser(this.username, this.password, null);
    this.service.login(loginUser).subscribe((auser: AuthUser) => {
      this.authUser = auser;
      this.store.saveUser(this.authUser);
      this.router.navigate(['/home']);
    });
  }

  public signOut(): void {
    if (this.store) {
      this.store.clear();
    }
  }

  public togglePasswordVisibility(): void {
    this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password';
  }
}
