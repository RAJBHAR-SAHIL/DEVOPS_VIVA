import { Component, OnInit } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { UserStoreService } from 'src/app/services/user-store.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminnav',
  templateUrl: './adminnav.component.html',
  styleUrls: ['./adminnav.component.css']
})
export class AdminnavComponent implements OnInit {
  
  isLogoutModalOpen = false;
  
  ngOnInit(): void {
  }

  constructor(public store:UserStoreService,private router:Router) { }
  
  public logOut(): void{
    this.store.getRole();
    if(this.store){
      this.store.clear();
    }
    this.router.navigate(['/login']);
  }

  public openLogoutModal(): void {
    this.isLogoutModalOpen = true;
  }

  public closeLogoutModal(): void {
    this.isLogoutModalOpen = false;
  }

  public confirmLogout(): void {
    this.logOut();
    this.closeLogoutModal();
  }
}
