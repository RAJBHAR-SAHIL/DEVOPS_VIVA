import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginUser } from 'src/app/models/login-user';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registerForm: FormGroup;
  passwordFieldType: string = 'password';
  confirmPasswordFieldType: string = 'password';

  constructor(private service: AuthService, private router: Router, private build: FormBuilder) {
    this.registerForm = this.build.group({
      username: ['', Validators.required],
      mobileNumber: ['', [Validators.required, Validators.pattern("^[0-9]{10}$")]],
      userRole: ['', Validators.required],
      password: ['', [Validators.required, Validators.pattern('^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$')]],
      email: ['', [Validators.required,Validators.email]],
      confirmPassword: ['', Validators.required]
    })
  }
  ngOnInit(): void {
  }
 
  register():void{
    console.log(this.registerForm)
    if(this.registerForm.valid){
      this.service.register(this.registerForm.value).subscribe(x=>{
        alert("signup successfull");
        this.router.navigate(['/home']);
      },err=>{
        alert("user already exists");
      })
    }
  }
  
  public toLogin(): void{
    this.router.navigate(['/login']);
  }
  
  public togglePasswordVisibility(): void {
    this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password';
  }

  public toggleConfirmPasswordVisibility(): void {
    this.confirmPasswordFieldType = this.confirmPasswordFieldType === 'password' ? 'text' : 'password';
  }
}