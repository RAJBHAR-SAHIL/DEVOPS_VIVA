import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FeedService } from 'src/app/services/feed.service';
import { Router } from '@angular/router'; // Import Router
import { UserStoreService } from 'src/app/services/user-store.service';
import { Feed } from 'src/app/models/feed.model';
 
@Component({
  selector: 'app-createfeed',
  templateUrl: './createfeed.component.html',
  styleUrls: ['./createfeed.component.css']
})
export class CreatefeedComponent implements OnInit {
  feedForm: FormGroup;
  selectedFile: string | null = null;
  errorMessage = null;
  modalVisible = false;
  addFeeds: Feed;
  userId: number = this.store.getId();
 
  constructor(
    private fb: FormBuilder,
    private service: FeedService,
    private router: Router,
    private store: UserStoreService
  ) { }
 
  ngOnInit(): void {
    this.feedForm = this.fb.group({
      feedName: ['', Validators.required],
      type: ['', Validators.required],
      description: ['', Validators.required],
      quantity: [0, [Validators.required, Validators.min(1)]],
      unit: ['', Validators.required],
      pricePerUnit: [0, [Validators.required, Validators.min(1)]],
      image: ['']
    });
  }
 
  onFileSelected(event: any) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      this.convertToBase64(file);
    }
  }
 
  base64Image: string;
  convertToBase64(file: File) {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      this.base64Image = reader.result as string;
      this.base64Image = this.base64Image.split(',')[1];
    };
    reader.onerror = (error) => {
    };
  }
 
  addFeed(): void {
    if (this.feedForm.invalid) {
      this.feedForm.markAllAsTouched();
    } else {
      const formValue = this.feedForm.value;
      const feedData: Feed = {
        feedName: formValue.feedName,
        type: formValue.type,
        description: formValue.description,
        quantity: formValue.quantity,
        unit: formValue.unit,
        pricePerUnit: formValue.pricePerUnit,
        image: this.base64Image,
        user: {
          userId: this.userId
        }
      };
 
      this.service.addFeed(feedData).subscribe(
        () => {
          this.modalVisible = true;
          this.feedForm.reset();
        },
        error => {
          this.errorMessage = "Feed with the same name and type already exists";
        }
      );
    }
  }
 
  isFieldInvalid(field: string): boolean {
    return !this.feedForm.get(field)?.valid && this.feedForm.get(field)?.touched;
  }
 
  navigateToViewFeed(): void {
    this.router.navigate(['/viewFeed']);
  }
}
 