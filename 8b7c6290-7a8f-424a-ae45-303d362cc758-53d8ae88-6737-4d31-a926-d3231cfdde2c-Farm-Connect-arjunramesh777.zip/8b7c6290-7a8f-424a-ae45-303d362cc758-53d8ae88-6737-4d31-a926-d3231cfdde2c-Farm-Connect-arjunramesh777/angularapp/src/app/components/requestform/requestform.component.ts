import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Livestock } from 'src/app/models/livestock.model';
import { Request } from 'src/app/models/request.model';
import { LivestockService } from 'src/app/services/livestock.service';
import { RequestService } from 'src/app/services/request.service';
import { UserStoreService } from 'src/app/services/user-store.service';

@Component({
  selector: 'app-requestform',
  templateUrl: './requestform.component.html',
  styleUrls: ['./requestform.component.css']
})
export class RequestformComponent implements OnInit {

  requestForm: FormGroup;
  livestocks: Livestock[] = [];
  modalVisible: boolean = false; 
  
  sourceComponent: string = '';
  medicineId: number = 0;
  feedId: number = 0;
  userId: number = this.store.getId(); 

  constructor(
    private fb: FormBuilder,
    private requestService: RequestService,
    private route: ActivatedRoute,
    private router: Router,
    private liveStockService: LivestockService,
    private store: UserStoreService
  ) {}

  ngOnInit(): void {
    this.requestForm = this.fb.group({
      requestType: ['', Validators.required],
      medicineName: [''],
      feedName: [''],
      quantity: [0, [Validators.required, Validators.min(1)]],
      status: ['Pending', Validators.required],
      livestockId: [0, Validators.required],
      requestDate: [new Date(), Validators.required]
    });

    this.requestForm.get('requestType')?.valueChanges.subscribe(requestType => {
      const medicineNameControl = this.requestForm.get('medicineName');
      const feedNameControl = this.requestForm.get('feedName');

      if (requestType === 'Medicine') {
        medicineNameControl?.setValidators(Validators.required);
        feedNameControl?.clearValidators();
      } else if (requestType === 'Feed') {
        feedNameControl?.setValidators(Validators.required);
        medicineNameControl?.clearValidators();
      } else {
        medicineNameControl?.clearValidators();
        feedNameControl?.clearValidators();
      }

      medicineNameControl?.updateValueAndValidity();
      feedNameControl?.updateValueAndValidity();
    });

    this.route.queryParams.subscribe(params => {
      this.requestForm.patchValue({
        requestType: params['requestType'],
        medicineName: params['mName'],
        feedName: params['fName']
      });
      this.medicineId = params['mId'];
      this.feedId = params['fId'];
      this.sourceComponent = params['sourceComponent'];
    });

    this.liveStockService.getLivestockByUserId(this.userId).subscribe(x => {
      this.livestocks = x;
    });
  }

  onSubmit(): void {
    
    if (this.requestForm.invalid) {
      this.requestForm.markAllAsTouched();
      return;
    }

    const requestData: Request = {
      ...this.requestForm.value,
      user: {
        userId: this.userId
      },
      medicine: {
        medicineId: this.medicineId,
      },
      feed: {
        feedId: this.feedId
      },
      livestock: { livestockId: this.requestForm.value.livestockId }
    };

    console.log('Request Data:', requestData); 

    this.requestService.addRequest(requestData).subscribe(
      () => {
        this.modalVisible = true; 
      },
      error => {
      }
    );
  }

  onCancel(): void {
    this.redirectToSourceComponent();
  }

  navigateToViewMedicine(): void {
    this.modalVisible = false; 
    this.redirectToSourceComponent();
  }

  private redirectToSourceComponent(): void {
    if (this.sourceComponent === 'ownerviewmedicine') {
      this.router.navigate(['/ownerViewMedicine']);
    } else if (this.sourceComponent === 'ownerviewfeed') {
      this.router.navigate(['/ownerViewFeed']);
    }
  }

  isFieldInvalid(field: string): boolean {
    return !this.requestForm.get(field)?.valid && this.requestForm.get(field)?.touched;
  }
}
