import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Livestock } from 'src/app/models/livestock.model';
import { LivestockService } from 'src/app/services/livestock.service';
import { UserStoreService } from 'src/app/services/user-store.service';

@Component({
  selector: 'app-ownereditlivestock',
  templateUrl: './ownereditlivestock.component.html',
  styleUrls: ['./ownereditlivestock.component.css']
})
export class OwnereditlivestockComponent implements OnInit {

  @Output() livestockUpdated = new EventEmitter<void>();

  editId: number;
  errorMessage: string = '';
  addLiveStock: FormGroup;
  userId:number = this.store.getId();
  modalVisible = false;

  constructor(private route: ActivatedRoute, private service: LivestockService, private fb: FormBuilder,private store:UserStoreService, private router:Router) {
    this.addLiveStock = this.fb.group({
      name: ['', Validators.required],
      species: ['', Validators.required],
      age: ['', Validators.required],
      breed: ['', Validators.required],
      healthCondition: ['', Validators.required],
      location: ['', Validators.required],
      vaccinationStatus: ['', Validators.required]
    })
  }

  ngOnInit(): void {
    this.editId = this.route.snapshot.params['livestockId'];
    this.service.getLivestockById(this.editId).subscribe((x) => {
      this.addLiveStock.patchValue(x);

    })
  }

  updateLivestocks() {
    if (this.addLiveStock.invalid) {
      this.addLiveStock.markAllAsTouched();
    }
    else {
      const formValue = this.addLiveStock.value;
      const LiveStockeData: Livestock = {
        name: formValue.name,
        species: formValue.species,
        age: formValue.age,
        breed: formValue.breed,
        healthCondition: formValue.healthCondition,
        location: formValue.location,
        vaccinationStatus: formValue.vaccinationStatus,
        user: {
          userId : this.userId
        }
      }
      this.service.updateLivestock(this.editId, LiveStockeData).subscribe(() => {
        this.modalVisible = true;
        this.addLiveStock.reset();
        
      }, error => {
        if (error.status === 500) {
          this.errorMessage = 'Livestock with the same name, breed, and species already exists'
        }
      });
    }
  }
  navigateToViewLiveStock(): void {
    this.router.navigate(['/viewLivestock']);
  }
}
