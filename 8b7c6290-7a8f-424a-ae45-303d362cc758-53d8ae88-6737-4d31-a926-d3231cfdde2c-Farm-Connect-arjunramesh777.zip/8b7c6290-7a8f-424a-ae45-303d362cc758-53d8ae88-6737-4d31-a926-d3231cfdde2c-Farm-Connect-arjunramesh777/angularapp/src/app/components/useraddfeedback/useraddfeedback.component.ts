import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Feedback } from 'src/app/models/feedback.model';
import { FeedbackService } from 'src/app/services/feedback.service';
import { UserStoreService } from 'src/app/services/user-store.service';

@Component({
  selector: 'app-useraddfeedback',
  templateUrl: './useraddfeedback.component.html',
  styleUrls: ['./useraddfeedback.component.css']
})
export class UseraddfeedbackComponent implements OnInit {
  FeedBackForm: FormGroup;
  userId: number = this.store.getId();
  addFeedBacks: Feedback = {};
  isSubmitted: boolean = false; 
  showPopup: boolean = false; 

  constructor(private service: FeedbackService, private build: FormBuilder, private store: UserStoreService) {
    this.FeedBackForm = this.build.group({
      feedbackText: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  addFeedBack() {
    if (this.FeedBackForm.valid) {
      const formValue = this.FeedBackForm.value;
      const feedbackData: Feedback = {
        feedbackText: formValue.feedbackText,
        date: new Date(),
        user: {
          userId: this.userId
        }
      };
      return this.service.addFeedback(feedbackData).subscribe(() => {
        this.FeedBackForm.reset();
        this.isSubmitted = true; 
        this.showPopup = true; 
      });
    }
  }

  closePopup() {
    this.showPopup = false; 
  }
}
