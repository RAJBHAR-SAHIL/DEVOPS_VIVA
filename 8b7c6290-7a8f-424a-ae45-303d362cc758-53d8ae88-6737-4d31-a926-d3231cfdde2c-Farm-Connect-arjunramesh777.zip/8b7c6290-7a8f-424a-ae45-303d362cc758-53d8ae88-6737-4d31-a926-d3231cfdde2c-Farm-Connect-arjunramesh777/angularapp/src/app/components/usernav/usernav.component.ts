import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserStoreService } from 'src/app/services/user-store.service';

@Component({
  selector: 'app-usernav',
  templateUrl: './usernav.component.html',
  styleUrls: ['./usernav.component.css']
})
export class UsernavComponent implements OnInit {

  isLogoutModalOpen = false;

  ngOnInit(): void {
  }

  constructor(public store: UserStoreService, private router: Router) { }
  
  public logOut(): void {
    this.store.getRole();
    if (this.store) {
      this.store.clear();
    }
    this.router.navigate(['/login']);
  }

  public openLogoutModal(): void {
    this.isLogoutModalOpen = true;
  }

  public closeLogoutModal(): void {
    this.isLogoutModalOpen = false;
  }

  public confirmLogout(): void {
    this.logOut();
    this.closeLogoutModal();
  }
}
