import { Component, OnInit } from '@angular/core';
import { UserStoreService } from './services/user-store.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'angularapp';
  isHomePage: boolean = false;

  constructor(public store:UserStoreService,private router: Router){
    this.router.events.subscribe(() => {
      this.isHomePage = this.router.url === '/home';
    });
  }

  role:string;

  ngOnInit(): void {
   
  }
}
